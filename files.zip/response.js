module.exports.run = (db, req) => retorno(db, req)
// Open Source - By: Lucas F. Silveira.
function retorno(db, req) {
    const dir = `arrays/${req}`
    function get(varName, functionName) {
        return `db.ref(\`${dir}\`).once('value').then((x) => { ${varName} = x.val() ? eval(x.val().array) : console.error('NODE_NOT_FOUND'); ${functionName}() })`
    }
    function set(res) {
        try {
            db.ref(dir).set({ array: `${res}` })
        } catch(er) {
            throw new TypeError(`FIreray:13 - response.js\n[there was a problem setar the array in the informed directory. Check database rules.]\n`+er)
        }
    }

    const obj = new Object();
    obj.get = (varName, functionName) => get(varName, functionName);
    obj.set = (res) => set(res) 

    return obj;
}