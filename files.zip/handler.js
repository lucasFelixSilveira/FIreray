module.exports = (db, type, req) => {
    // Open Source - By: Lucas F. Silveira.
    const FIreray = require('./response.js')
    if( type == true ) { // Coletar o array
        if(! req['dir'] ) return console.error('You need to tell the directory where you want to search.')
        if(! req['var'] ) return console.error('You need to enter the name of the variable that you want to save the array.')
        if(! req['exe'] ) return console.error('You need to enter the NAME of the function you want to run after saving the array.')
        return FIreray.run(db, req['dir']).get(req['var'], req['exe']); 
    } else if( type == false ) { // Setar o array
        if(! req['dir'] ) return console.error('You need to tell the directory where you want to define the array.')
        if(! req['val'] ) return console.error('You need to tell the array you want to save.')
        return FIreray.run(db, req['dir']).set(req['val']); 
    } else return console.error('The second argument passed can only be TRUE or FALSE')
}